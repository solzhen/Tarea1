package Main;

import java.util.ArrayList;

import Geometry.Rectangle;
import Node.*;
import RTree.RTree;

public class Experiment {

  public static void main(String[] args) throws InterruptedException {
	  Thread.sleep(5000);
	  ArrayList<InnerNode> nodes = new ArrayList<>();
	  for (int i = 0; i < 5000; i++) {
	  LeafNode lf = new LeafNode(10);
	  lf.insertar(new Rectangle(0,0,1,1));
	  InnerNode in = new InnerNode(lf, null);	
	  nodes.add(in);
	  }
	  int whatever = 0;
	  for(InnerNode n: nodes) {
		  whatever++;
	  }
	  System.out.println(whatever + nodes.get(0).toString())
	    ;
	  Thread.sleep(1000);
  }
}
