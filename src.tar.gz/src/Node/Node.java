package Node;

import java.io.Serializable;
import java.util.ArrayList;

import Geometry.Rectangle;

public class Node implements Serializable{
  public InnerNode parent; //4 bytes ----4⁶
  public Rectangle mbr; // 32 bytes == 4²*2  -----48 ---5*174
  public int Eme; //4 bytes
  public String path;
  public ArrayList<Rectangle> buscar(Rectangle rect) {
    return null;
  }
  public LeafNode insertar(Rectangle rect) {
    return null;
  }
  public void fix() {
  }
  public String display(int i) {
    return null;
  }
  public int getDepth() {return 0;}
  public int countSelf() { return 1;}
  public int countLeaf() { return 1;}
    
}
