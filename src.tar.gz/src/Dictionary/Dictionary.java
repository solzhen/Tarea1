package Dictionary;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;

import Geometry.Rectangle;
import Serializables.*;

public class Dictionary {
	public static int getIndex(SerializableNode n) {
		String serializedObject = "";
		try {
		     ByteArrayOutputStream bo = new ByteArrayOutputStream();
		     ObjectOutputStream so = new ObjectOutputStream(bo);
		     so.writeObject(n);
		     so.flush();
		     serializedObject = bo.toString();
		 } catch (Exception e) {
			 e.printStackTrace();
		 }
		String file = "Dict.txt";
		int lastIn = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
		    String line;
		    		    
		    while ((line = br.readLine()) != null) {
		    	String index = "";
		    	int i = 0;
		    	char c;
		    	while ((c = line.charAt(i)) != '$') {
		    		index = index + c; i++;
		    	}		
		    	int in = Integer.parseInt(index);
		    	line = line.substring(i + 1);
		    	if (line.equals(serializedObject)) {
		    		return in;
		    	}
		    	lastIn = in;
		    }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return 0;
	}

	public static SerializableNode getNode(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	public static Rectangle getRect(int i) {
		return null;
	}
}
